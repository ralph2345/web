<?php
session_start();
require 'config.php';

$is_admin = false;
if (isset($_SESSION['admin_name'])) {
    $logged_in_user = $_SESSION['admin_name'];
    $is_admin = true;
} else {
    $logged_in_user = 'Guest';
}

$limit = 10;
if (isset($_GET["page"])) {
    $page = $_GET["page"];
} else {
    $page = 1;
};
$start_from = ($page - 1) * $limit;

$sql = "SELECT * FROM order_form LIMIT $start_from, $limit";
$result = mysqli_query($conn, $sql);

$total_records_query = "SELECT COUNT(*) FROM order_form";
$total_records_result = mysqli_query($conn, $total_records_query);
$total_records = mysqli_fetch_array($total_records_result)[0];
$total_pages = ceil($total_records / $limit);

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Management - Quantify</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.9.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="Orders.css">
</head>
<body>
<header>
    <div class="header-left">
        <div>Welcome, <?php echo htmlspecialchars($logged_in_user); ?></div>
    </div>
</header>
<div class="container">
    <aside class="sidebar" id="sidebar">
        <button class="toggle-btn" onclick="toggleSidebar()"><i class="bi bi-list"></i></button> 
        <h2 id="menuHeader">Menu</h2>
        <ul>
            <?php if ($is_admin) : ?>
            <li><a href="Dashboard.php"><i class="bi bi-person-video"></i> <span>Dashboard</span></a></li>
            <li><a href="Reports.php"><i class="bi bi-clipboard-data"></i> <span>Reports</span></a></li>
            <li><a href="Product.php"><i class="bi bi-box2"></i> <span>Products</span></a></li>
            <li><a href="emailForm.php"><i class="bi bi-envelope"></i> <span>Mail</span></a></li>
            <li><a href="Orders.php"><i class="bi bi-bag-check"></i> <span>Orders</span></a></li>
            <li><a href="Reservations.php"><i class="bi bi-check2-square"></i> <span>Reservations</span></a></li>
            <li><a href="logout.php" id="logoutLink"><i class="bi bi-box-arrow-left"></i> <span>Sign Out</span></a></li>
            <?php else : ?>
            <li><a href="Product.php"><i class="bi bi-box2"></i> <span>Products</span></a></li>
            <li><a href="Cart.php"><i class="bi bi-bag-check"></i> <span>Cart</span></a></li>
            <li><a href="logout.php" id="exitLink"><i class="bi bi-box-arrow-left"></i> <span>Exit</span></a></li>
            <?php endif; ?>
        </ul>
    </aside>
    <main class="main-content">
    <h1>Order Lists</h1>
        <table>
            <thead>
                <tr>
                    <th>Order no.</th>
                    <th>Name</th>
                    <th>Number</th>
                    <th>Email</th>
                    <th>Total Products</th>
                    <th>Total Price</th>
                    <th>Order Date</th>
                    <th>Pickup Date</th>
                    <th>Pickup Time</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['Order_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['number']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['total_products']); ?></td>
                    <td><?php echo htmlspecialchars($row['total_price']); ?></td>
                    <td><?php echo htmlspecialchars($row['order_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['pickup_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['pickup_time']); ?></td>
                    <td>
                        <select class="status-dropdown" data-order-id="<?php echo $row['Order_id']; ?>">
                            <option value="Pending" <?php if ($row['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                            <option value="Completed" <?php if ($row['status'] == 'Completed') echo 'selected'; ?>>Completed</option>
                        </select>
                    </td>
                    <td>
                        <button class="btn-print" data-order-id="<?php echo $row['Order_id']; ?>" data-table="order_form"><i class="bi bi-printer"></i> Print</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php if($page > 1): ?>
                <a href="Orders.php?page=<?php echo ($page - 1); ?>" class="page-link previous round"><i class="bi bi-chevron-left"></i></a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="Orders.php?page=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a>
            <?php endfor; ?>
            <?php if($page < $total_pages): ?>
                <a href="Orders.php?page=<?php echo ($page + 1); ?>" class="page-link next round"><i class="bi bi-chevron-right"></i></a>
            <?php endif; ?>
        </div>
    </main>
</div>
<footer>
    <p>&copy; 2024 <a href="#" style="color: white;">Quantify</a>. All rights reserved.</p>
</footer>
<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('minimized');
        const menuHeader = document.getElementById('menuHeader');
        menuHeader.style.display = sidebar.classList.contains('minimized') ? 'none' : 'inline';
    }

    document.getElementById('logoutLink').addEventListener('click', function(event) {
        event.preventDefault();
        if (confirm('Are you sure you want to sign out?')) {
            window.location.href = this.href;
        }
    });

    document.querySelectorAll('.status-dropdown').forEach(function(dropdown) {
        dropdown.addEventListener('change', function() {
            var orderId = this.getAttribute('data-order-id');
            var newStatus = this.value;

            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'update_status.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (this.status == 200) {
                    alert('Status updated successfully');
                } else {
                    alert('Error updating status');
                }
            };
            xhr.send('order_id=' + encodeURIComponent(orderId) + '&status=' + encodeURIComponent(newStatus));
        });
    });

    document.querySelectorAll('.btn-print').forEach(function(button) {
        button.addEventListener('click', function() {
            var orderId = this.getAttribute('data-order-id');
            var table = this.getAttribute('data-table');
            window.location.href = 'download_receipt.php?order_id=' + orderId + '&table=' + table;
        });
    });
</script>
</body>
</html>