<?php
require 'config.php';

$input = json_decode(file_get_contents('php://input'), true);
$id = $input['id'];
$status = $input['status'];

$query = "UPDATE reserved_form SET status = ? WHERE Reserved_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, 'si', $status, $id);

$response = ['success' => false];
if (mysqli_stmt_execute($stmt)) {
    $response['success'] = true;
}

mysqli_stmt_close($stmt);
mysqli_close($conn);

header('Content-Type: application/json');
echo json_encode($response);
?>
