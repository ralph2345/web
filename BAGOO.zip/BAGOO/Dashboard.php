<?php
session_start();
require 'config.php';

$is_admin = false;
if (isset($_SESSION['admin_name'])) {
    $logged_in_user = $_SESSION['admin_name'];
    $is_admin = true;
} else {
    $logged_in_user = 'Guest';
}

$orders_per_page = 6;
$reservations_per_page = 6;
$order_page = isset($_GET['order_page']) ? (int)$_GET['order_page'] : 1;
$reservation_page = isset($_GET['reservation_page']) ? (int)$_GET['reservation_page'] : 1;
$order_offset = ($order_page - 1) * $orders_per_page;
$reservation_offset = ($reservation_page - 1) * $reservations_per_page;

$total_products = 0;
$total_stock = 0;
$total_orders = 0;
$total_pending_orders = 0;
$total_pending_reservations = 0;

if ($is_admin) {
    $product_query = "SELECT COUNT(*) AS total_products, SUM(small_stock + medium_stock + large_stock + xl_stock + xxl_stock + accessories_stock) AS total_stock FROM product";
    $product_result = mysqli_query($conn, $product_query);
    if ($product_result) {
        $product_row = mysqli_fetch_assoc($product_result);
        $total_products = $product_row['total_products'];
        $total_stock = $product_row['total_stock'];
    }

    $order_query = "SELECT COUNT(*) AS total_orders FROM order_form";
    $order_result = mysqli_query($conn, $order_query);
    if ($order_result) {
        $order_row = mysqli_fetch_assoc($order_result);
        $total_orders = $order_row['total_orders'];
    }

    $pending_order_query = "SELECT COUNT(*) AS total_pending_orders FROM order_form WHERE status = 'Pending'";
    $pending_order_result = mysqli_query($conn, $pending_order_query);
    if ($pending_order_result) {
        $pending_order_row = mysqli_fetch_assoc($pending_order_result);
        $total_pending_orders = $pending_order_row['total_pending_orders'];
    }

    $pending_reservation_query = "SELECT COUNT(*) AS total_pending_reservations FROM reserved_form WHERE status = 'Pending'";
    $pending_reservation_result = mysqli_query($conn, $pending_reservation_query);
    if ($pending_reservation_result) {
        $pending_reservation_row = mysqli_fetch_assoc($pending_reservation_result);
        $total_pending_reservations = $pending_reservation_row['total_pending_reservations'];
    }
}

$pending_orders = [];
$pending_reservations = [];

if ($is_admin) {
    $pending_order_query = "SELECT Order_id, name, email, status FROM order_form WHERE status = 'Pending' LIMIT $orders_per_page OFFSET $order_offset";
    $pending_order_result = mysqli_query($conn, $pending_order_query);
    if ($pending_order_result) {
        while ($row = mysqli_fetch_assoc($pending_order_result)) {
            $pending_orders[] = $row;
        }
    }

    $pending_reservation_query = "SELECT Reserved_id, name, email, status FROM reserved_form WHERE status = 'Pending' LIMIT $reservations_per_page OFFSET $reservation_offset";
    $pending_reservation_result = mysqli_query($conn, $pending_reservation_query);
    if ($pending_reservation_result) {
        while ($row = mysqli_fetch_assoc($pending_reservation_result)) {
            $pending_reservations[] = $row;
        }
    }
}

$total_order_pages = ceil($total_pending_orders / $orders_per_page);
$total_reservation_pages = ceil($total_pending_reservations / $reservations_per_page);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Quantify</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.9.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="Dashboard.css">
</head>
<body>
<header>
    <div class="header-left">
        <div>Welcome, <?php echo htmlspecialchars($logged_in_user); ?></div>
    </div>
</header>
<div class="container">
    <aside class="sidebar" id="sidebar">
        <button class="toggle-btn" onclick="toggleSidebar()"><i class="bi bi-list"></i></button> 
        <h2 id="menuHeader">Menu</h2>
        <ul>
            <?php if ($is_admin) : ?>
            <li><a href="Dashboard.php"><i class="bi bi-person-video"></i> <span>Dashboard</span></a></li>
            <li><a href="Reports.php"><i class="bi bi-clipboard-data"></i> <span>Reports</span></a></li>
            <li><a href="Product.php"><i class="bi bi-box2"></i> <span>Products</span></a></li>
            <li><a href="emailForm.php"><i class="bi bi-envelope"></i> <span>Mail</span></a></li>
            <li><a href="Orders.php"><i class="bi bi-bag-check"></i> <span>Orders</span></a></li>
            <li><a href="Reservations.php"><i class="bi bi-check2-square"></i> <span>Reservations</span></a></li>
            <li><a href="logout.php" id="logoutLink"><i class="bi bi-box-arrow-left"></i> <span>Sign Out</span></a></li>
            <?php else : ?>
            <li><a href="Product.php"><i class="bi bi-box2"></i> <span>Products</span></a></li>
            <li><a href="Cart.php"><i class="bi bi-bag-check"></i> <span>Cart</span></a></li>
            <li><a href="logout.php" id="exitLink"><i class="bi bi-box-arrow-left"></i> <span>Exit</span></a></li>
            <?php endif; ?>
        </ul>
    </aside>
    <main class="main-content">
        <div class="dashboard">
            <div class="card blue">
                <i class="bi bi-box-seam"></i>
                <h3>Products</h3>
                <p><?php echo $total_products; ?></p>
                <a href="Product.php">View Details</a>
            </div>
            <div class="card red">
                <i class="bi bi-receipt"></i>
                <h3>Orders</h3>
                <p><?php echo $total_orders; ?></p>
                <a href="Orders.php">View Details</a>
            </div>
            <div class="card orange">
                <i class="bi bi-tags"></i>
                <h3>Pending Orders</h3>
                <p><?php echo $total_pending_orders + $total_pending_reservations; ?></p>
                <a href="Reservations.php">View Details</a>
            </div>
        </div>

        <div class="tables">
            <div class="table-container table-wrapper">
                <h3>Pending Orders</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Order ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($pending_orders)) : ?>
                        <tr><td colspan="4">No pending orders</td></tr>
                        <?php else : ?>
                        <?php foreach ($pending_orders as $order): ?>
                        <tr>
                            <td><?php echo $order['Order_id']; ?></td>
                            <td><?php echo htmlspecialchars($order['name']); ?></td>
                            <td><?php echo htmlspecialchars($order['email']); ?></td>
                            <td><?php echo $order['status']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php if ($total_order_pages > 1): ?>
                <div class="pagination">
                    <?php if ($order_page > 1): ?>
                        <a href="?order_page=<?php echo $order_page - 1; ?>">&laquo; Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_order_pages; $i++): ?>
                        <a href="?order_page=<?php echo $i; ?>" class="<?php echo $i == $order_page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($order_page < $total_order_pages): ?>
                        <a href="?order_page=<?php echo $order_page + 1; ?>">Next &raquo;</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <div class="table-container table-wrapper">
                <h3>Pending Reservations</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Reserved ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($pending_reservations)) : ?>
                        <tr><td colspan="4">No pending reservations</td></tr>
                        <?php else : ?>
                        <?php foreach ($pending_reservations as $reservation): ?>
                        <tr>
                            <td><?php echo $reservation['Reserved_id']; ?></td>
                            <td><?php echo htmlspecialchars($reservation['name']); ?></td>
                            <td><?php echo htmlspecialchars($reservation['email']); ?></td>
                            <td><?php echo $reservation['status']; ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
                <?php if ($total_reservation_pages > 1): ?>
                <div class="pagination">
                    <?php if ($reservation_page > 1): ?>
                        <a href="?reservation_page=<?php echo $reservation_page - 1; ?>">&laquo; Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_reservation_pages; $i++): ?>
                        <a href="?reservation_page=<?php echo $i; ?>" class="<?php echo $i == $reservation_page ? 'active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>
                    
                    <?php if ($reservation_page < $total_reservation_pages): ?>
                        <a href="?reservation_page=<?php echo $reservation_page + 1; ?>">Next &raquo;</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>
<footer>
    <p>&copy; 2024 <a href="#" style="color: white;">Quantify</a>. All rights reserved.</p>
</footer>
<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('minimized');
        const menuHeader = document.getElementById('menuHeader');
        menuHeader.style.display = sidebar.classList.contains('minimized') ? 'none' : 'inline';
    }

    document.getElementById('logoutLink').addEventListener('click', function(event) {
        event.preventDefault();
        if (confirm('Are you sure you want to sign out?')) {
            window.location.href = this.href;
        }
    });
</script>
</body>
</html>
