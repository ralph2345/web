<?php
session_start();
require 'config.php'; 


$is_admin = false;
if (isset($_SESSION['admin_name'])) {
    $logged_in_user = $_SESSION['admin_name'];
    $is_admin = true;
} else {
    $logged_in_user = 'Guest';
}

$limit = 10; 
if (isset($_GET["page"])) {
    $page = $_GET["page"];
} else {
    $page = 1;
};
$start_from = ($page - 1) * $limit;

$reservation_query = "SELECT Reserved_id, name, number, email, total_products, total_price, order_date, pickup_date, pickup_time, status FROM reserved_form ORDER BY Reserved_id ASC LIMIT $start_from, $limit";
$reservation_result = mysqli_query($conn, $reservation_query);

$total_records_query = "SELECT COUNT(*) FROM reserved_form";
$total_records_result = mysqli_query($conn, $total_records_query);
$total_records = mysqli_fetch_array($total_records_result)[0];
$total_pages = ceil($total_records / $limit);

$logged_in_user = $_SESSION['admin_name'];
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation - Quantify</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.9.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="Reservations.css">
</head>
<body>
<header>
    <div class="header-left">
        <div>Welcome, <?php echo htmlspecialchars($logged_in_user); ?></div>
    </div>
</header>
<div class="container">
    <aside class="sidebar" id="sidebar">
        <button class="toggle-btn" onclick="toggleSidebar()"><i class="bi bi-list"></i></button> 
        <h2 id="menuHeader">Menu</h2>
        <ul>
            <?php if ($is_admin) : ?>
            <li><a href="Dashboard.php"><i class="bi bi-person-video"></i> <span>Dashboard</span></a></li>
            <li><a href="Reports.php"><i class="bi bi-clipboard-data"></i> <span>Reports</span></a></li>
            <li><a href="Product.php"><i class="bi bi-box2"></i> <span>Products</span></a></li>
            <li><a href="emailForm.php"><i class="bi bi-envelope"></i> <span>Mail</span></a></li>
            <li><a href="Orders.php"><i class="bi bi-bag-check"></i> <span>Orders</span></a></li>
            <li><a href="Reservations.php"><i class="bi bi-check2-square"></i> <span>Reservations</span></a></li>
            <li><a href="logout.php" id="logoutLink"><i class="bi bi-box-arrow-left"></i> <span>Sign Out</span></a></li>
            <?php else : ?>
            <li><a href="Product.php"><i class="bi bi-box2"></i> <span>Products</span></a></li>
            <li><a href="Cart.php"><i class="bi bi-bag-check"></i> <span>Cart</span></a></li>
            <li><a href="logout.php" id="exitLink"><i class="bi bi-box-arrow-left"></i> <span>Exit</span></a></li>
            <?php endif; ?>
        </ul>
    </aside>
    <main class="main-content">
        <h1>Reservation Lists</h1>
        <table class="reservation-table">
            <thead>
                <tr>
                    <th>Reserved No.</th>
                    <th>Name</th>
                    <th>Number</th>
                    <th>Email</th>
                    <th>Total Products</th>
                    <th>Total Price</th>
                    <th>Order Date</th>
                    <th>Pickup Date</th>
                    <th>Pickup Time</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($reservation_result)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['Reserved_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['number']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['total_products']); ?></td>
                    <td><?php echo htmlspecialchars($row['total_price']); ?></td>
                    <td><?php echo htmlspecialchars($row['order_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['pickup_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['pickup_time']); ?></td>
                    <td>
                        <select name="status" class="status-dropdown" data-id="<?php echo htmlspecialchars($row['Reserved_id']); ?>">
                            <option value="Pending" <?php echo $row['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="Completed" <?php echo $row['status'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="Partially Completed" <?php echo $row['status'] == 'Partially Completed' ? 'selected' : ''; ?>>Partially Completed</option>
                        </select>
                    </td>
                    <td>
                    <button class="btn-print" data-order-id="<?php echo $row['Reserved_id']; ?>" data-table="reserved_form"><i class="bi bi-printer"></i> Print</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php if($page > 1): ?>
                <a href="Reservations.php?page=<?php echo ($page - 1); ?>" class="page-link previous round"><i class="bi bi-chevron-left"></i></a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <a href="Reservations.php?page=<?php echo $i; ?>" class="page-link"><?php echo $i; ?></a>
            <?php endfor; ?>
            <?php if($page < $total_pages): ?>
                <a href="Reservations.php?page=<?php echo ($page + 1); ?>" class="page-link next round"><i class="bi bi-chevron-right"></i></a>
            <?php endif; ?>
        </div>
    </main>
</div>
<footer>
    <p>&copy; 2024 <a href="#" style="color: white;">Quantify</a>. All rights reserved.</p>
</footer>
<script>
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        sidebar.classList.toggle('minimized');
        const menuHeader = document.getElementById('menuHeader');
        menuHeader.style.display = sidebar.classList.contains('minimized') ? 'none' : 'inline';
    }

    document.getElementById('logoutLink').addEventListener('click', function(event) {
        event.preventDefault();
        if (confirm('Are you sure you want to sign out?')) {
            window.location.href = this.href;
        }
    });

    document.querySelectorAll('.btn-print').forEach(function(button) {
        button.addEventListener('click', function() {
            var orderId = this.getAttribute('data-order-id');
            var table = this.getAttribute('data-table');
            window.location.href = 'download_receipt.php?order_id=' + orderId + '&table=' + table;
        });
    });

    document.querySelectorAll('.status-dropdown').forEach(function(selectElement) {
        selectElement.addEventListener('change', function() {
            const reservedId = this.getAttribute('data-id');
            const newStatus = this.value;

            fetch('update_reservation_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id: reservedId, status: newStatus })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Status updated successfully');
                } else {
                    alert('Failed to update status');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the status');
            });
        });
    });
</script>
</body>
</html>
