<?php
session_start();
require 'config.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    $sql = "UPDATE order_form SET status = ? WHERE Order_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'si', $status, $order_id);

    if (mysqli_stmt_execute($stmt)) {
        echo 'Status updated successfully';
    } else {
        http_response_code(500);
        echo 'Error updating status';
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
    exit;
} else {
    http_response_code(400);
    echo 'Invalid request method';
}
?>
