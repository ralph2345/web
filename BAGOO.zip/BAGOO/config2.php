<?php

// smtp mail server
define('MAILHOST', "smtp.gmail.com");

define('USERNAME', "stibalagtas2024@gmail.com");

// password in app password
define('PASSWORD', "ijcu tnhr tvcz wsaa");

// define email address from which the email is sent
define('SEND_FROM', "stibalagtas2024@gmail.com");

// define the website name from which email is sent
define('SEND_FROM_NAME', "Quantify");

//define reply to address
define('REPLY_TO', "stibalagtas2024@gmail.com");

// name of reply to name
define('REPLY_TO_NAME', "Students");
?>
