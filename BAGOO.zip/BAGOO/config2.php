<?php

define('MAILHOST', "smtp.gmail.com");

define('USERNAME', "stibalagtas2024@gmail.com");

define('PASSWORD', "ijcu tnhr tvcz wsaa");

define('SEND_FROM', "stibalagtas2024@gmail.com");

define('SEND_FROM_NAME', "Quantify");

define('REPLY_TO', "stibalagtas2024@gmail.com");

define('REPLY_TO_NAME', "Students");
?>
