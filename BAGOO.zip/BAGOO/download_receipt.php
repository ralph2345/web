<?php
ob_start(); // Start output buffering

require_once('tcpdf/tcpdf.php');
require 'config.php';

if (isset($_GET['order_id'])) {
    $order_id = intval($_GET['order_id']);

    // Fetch the order details from the database
    $sql = "SELECT * FROM order_form WHERE Order_id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, 'i', $order_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $name = htmlspecialchars($row['name']);
        $number = htmlspecialchars($row['number']);
        $email = htmlspecialchars($row['email']);
        $pickup_date = htmlspecialchars($row['pickup_date']);
        $total_products = htmlspecialchars($row['total_products']);
        $grand_total = number_format($row['total_price'], 2);

        // Create new PDF document
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

        // Set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('STI College Balagtas');
        $pdf->SetTitle('Order Receipt');
        $pdf->SetSubject('Receipt');

        // Set default header data
        $pdf->SetHeaderData('', 0, 'STI College Balagtas', "Address: RWF2+697, MacArthur Hwy, Balagtas, Bulacan\nTelp. 11223344");

        // Set header and footer fonts
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

        // Set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // Set margins
        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

        // Set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        // Set image scale factor
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

        // Add a page
        $pdf->AddPage();

        // Set some content to print
        $html = "
        <style>
            .receipt-container {
                text-align: center;
            }
            .receipt-table {
                margin: 0 auto;
                width: 60%;
                text-align: center;
                border-collapse: collapse;
            }
            .receipt-table th, .receipt-table td {
                border: 1px solid #000;
                padding: 10px;
            }
            .receipt-details {
                text-align: center;
                margin: 20px 0;
            }
            .total {
                font-weight: bold;
                margin-top: 10px;
            }
        </style>
        <div class='receipt-container'>
            <h3>CASH RECEIPT</h3>
            <table class='receipt-table'>
                <tr>
                    <th>Description</th>
                    <th>Price</th>
                </tr>
                <tr>
                    <td>{$total_products}</td>
                    <td>Php {$grand_total}</td>
                </tr>
            </table>
            <h4 class='total'>Total: Php {$grand_total}</h4>
            <div class='receipt-details'>
                <p>Order No.: {$order_id}</p>
                <p>Your Name: {$name}</p>
                <p>Your Number: {$number}</p>
                <p>Your Email: {$email}</p>
                <p>Pickup Date: {$pickup_date}</p>
                <p>THANK YOU!</p>
            </div>
        </div>";

        // Print text using writeHTMLCell()
        $pdf->writeHTML($html, true, false, true, false, '');

        // Close and output PDF document
        ob_end_clean(); // Clear the output buffer
        $pdf->Output('receipt.pdf', 'D');
    } else {
        ob_end_clean(); // Clear the output buffer
        echo "Order not found.";
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {
    ob_end_clean(); // Clear the output buffer
    echo "Invalid request.";
}
?>
