<?php
session_start();
require 'config.php'; // Include your database connection

// Determine if an admin is logged in
$is_admin = false;
$logged_in_user = 'Guest';
if (isset($_SESSION['admin_name'])) {
    $logged_in_user = $_SESSION['admin_name'];
    $is_admin = true;
}

// Function to fetch stock levels
function getStockLevels($conn) {
    $sql = "SELECT name, 
                   (small_stock + medium_stock + large_stock + xl_stock + xxl_stock + accessories_stock) as total_stock 
            FROM product";
    $result = $conn->query($sql);
    $stockLevels = [];
    while ($row = $result->fetch_assoc()) {
        $stockLevels[] = $row;
    }
    return $stockLevels;
}

// Function to fetch sales trends
function getSalesTrends($conn) {
    $sql = "SELECT DATE(order_date) as date, SUM(total_price) as total_sales 
            FROM order_form 
            GROUP BY DATE(order_date)";
    $result = $conn->query($sql);
    $salesTrends = [];
    while ($row = $result->fetch_assoc()) {
        $salesTrends[] = $row;
    }
    return $salesTrends;
}

// Function to fetch reservation trends
function getReservationTrends($conn) {
    $sql = "SELECT DATE(order_date) as date, COUNT(*) as total_reservations 
            FROM reserved_form 
            GROUP BY DATE(order_date)";
    $result = $conn->query($sql);
    $reservationTrends = [];
    while ($row = $result->fetch_assoc()) {
        $reservationTrends[] = $row;
    }
    return $reservationTrends;
}

// Fetch data
$stockLevels = getStockLevels($conn);
$salesTrends = getSalesTrends($conn);
$reservationTrends = getReservationTrends($conn);


// Convert PHP arrays to JSON
$stockLevelsJson = json_encode($stockLevels);
$salesTrendsJson = json_encode($salesTrends);
$reservationTrendsJson = json_encode($reservationTrends);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - Quantify</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.9.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="Reports.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <header>
        <div class="header-left">
            <div>Welcome, <?php echo htmlspecialchars($logged_in_user); ?></div>
        </div>
    </header>
    <div class="container">
        <aside class="sidebar" id="sidebar">
            <button class="toggle-btn" onclick="toggleSidebar()"><i class="bi bi-list"></i></button> 
            <h2 id="menuHeader">Menu</h2>
            <ul>
                <li><a href="Dashboard.php"><i class="bi bi-person-video"></i> <span>Dashboard</span></a></li>
                <li><a href="Reports.php"><i class="bi bi-clipboard-data"></i> <span>Reports</span></a></li>
                <li><a href="Product.php"><i class="bi bi-box2"></i> <span>Products</span></a></li>
                <li><a href="emailForm.php"><i class="bi bi-envelope"></i> <span>Mail</span></a></li>
                <li><a href="Orders.php"><i class="bi bi-bag-check"></i> <span>Orders</span></a></li>
                <li><a href="Reservations.php"><i class="bi bi-check2-square"></i> <span>Reservations</span></a></li>
                <li><a href="logout.php" id="logoutLink"><i class="bi bi-box-arrow-left"></i> <span>Sign Out</span></a></li>
            </ul>
        </aside>
        <main>
            <h1>Reports</h1>
            <div class="charts-container">
                <div class="chart-container">
                    <div class="chart-title">Products Stocks</div>
                    <canvas id="stockLevelsChart"></canvas>
                </div>
                <div class="chart-container">
                    <div class="chart-title">Sales and Reservation Trends</div>
                    <canvas id="trendsChart"></canvas>
                </div>
            </div>
        </main>
    </div>
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('minimized');
            const menuHeader = document.getElementById('menuHeader');
            menuHeader.style.display = sidebar.classList.contains('minimized') ? 'none' : 'inline';
        }

        document.getElementById('logoutLink').addEventListener('click', function(event) {
            event.preventDefault();
            if (confirm('Are you sure you want to sign out?')) {
                window.location.href = this.href;
            }
        });

        // Stock Levels Data
        const stockLevelsData = <?php echo $stockLevelsJson; ?>;
        const stockLevelsLabels = stockLevelsData.map(item => item.name);
        const stockLevelsValues = stockLevelsData.map(item => item.total_stock);

        // Sales Trends Data
        const salesTrendsData = <?php echo $salesTrendsJson; ?>;
        const salesTrendsLabels = salesTrendsData.map(item => item.date);
        const salesTrendsValues = salesTrendsData.map(item => item.total_sales);

        // Reservation Trends Data
        const reservationTrendsData = <?php echo $reservationTrendsJson; ?>;
        console.log('Reservation Trends Data:', reservationTrendsData);

        const reservationTrendsLabels = reservationTrendsData.map(item => item.date);
        const reservationTrendsValues = reservationTrendsData.map(item => item.total_reservations);

        // Format dates as months
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        const formattedSalesLabels = salesTrendsLabels.map(date => {
            const d = new Date(date);
            return `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
        });
        const formattedReservationLabels = reservationTrendsLabels.map(date => {
            const d = new Date(date);
            return `${monthNames[d.getMonth()]} ${d.getFullYear()}`;
        });

        // Merge labels to cover all dates
        const allLabels = [...new Set([...salesTrendsLabels, ...reservationTrendsLabels])].sort((a, b) => new Date(a) - new Date(b));

        // Align data for merged labels
        const alignedSalesValues = allLabels.map(label => {
            const item = salesTrendsData.find(data => data.date === label);
            return item ? item.total_sales : 0;
        });

        const alignedReservationValues = allLabels.map(label => {
            const item = reservationTrendsData.find(data => data.date === label);
            return item ? item.total_reservations : 0;
        });

        // Stock Levels Chart
        new Chart(document.getElementById('stockLevelsChart'), {
            type: 'bar',
            data: {
                labels: stockLevelsLabels,
                datasets: [{
                    label: 'Stock Levels',
                    data: stockLevelsValues,
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(153, 102, 255, 0.2)'
                    ],
                    borderColor: [
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 99, 132, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(153, 102, 255, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Combined Trends Chart
        new Chart(document.getElementById('trendsChart'), {
            type: 'line',
            data: {
                labels: allLabels,
                datasets: [
                    {
                        label: 'Sales Trends',
                        data: alignedSalesValues,
                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1,
                        fill: true
                    },
                    {
                        label: 'Reservation Trends',
                        data: alignedReservationValues,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    title: {
                        display: false
                    }
                },
                scales: {
                    x: {
                        type: 'category',
                        labels: allLabels
                    },
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
